Toolsredo is a mod for Minetest that adds some tools which make the gameplay a bit easier.
More info:
https://forum.minetest.net/viewtopic.php?p=263522&sid=d1e9e0c908b9578488cc9e989fe4875d#p263522
